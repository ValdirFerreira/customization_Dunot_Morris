﻿
$(function () {
    graficoValdir.CarregaGrafico();
    graficoValdir.handleSetInterval = setInterval(graficoValdir.Atualizar, graficoValdir.IntervaloDeAtualizacao);
});



var graficoValdir = new Object();

graficoValdir.Nomeelemento = "graph";
graficoValdir.browsersChart = "";
graficoValdir.IntervaloDeAtualizacao = 3000;
graficoValdir.select = 0;

// Legendas 
graficoValdir.DivLegenda = "legend";


graficoValdir.Data = [
    { label: "Compras", value: 10, motivo: 0, color: "#00D077" },
    { label: "Dividas", value: 20, motivo: 1, color: "#e74c3c" },
    { label: "Compras Futuras", value: 30, motivo: 2, color: "#FFBF00" },
    { label: "Vendas", value: 40, motivo: 3, color: "#0791FB" },
    { label: "Pedidos pendentes", value: 50, motivo: 4, color: "#666666" },
    { label: "Pedidos futuros", value: 60, motivo: 5, color: "#7668ff" },
];

graficoValdir.GerarLegendas = function () {
    graficoValdir.browsersChart.options.data.forEach(function (label, i) {
        var lagendaitem = $('<span id="legend_' + graficoValdir.Data[i].motivo + '"></span>')
            .text(label['label'] + "(" + label['label'] + " )").prepend('</br><span>&nbsp;</span>')
        lagendaitem.find('span')
            .css('backgroundColor', graficoValdir.Data[i].color)
            .css('width', '20px')
            .css('display', 'inline-block')
            .css('margin', '5px');

        $("#" + graficoValdir.DivLegenda).append(lagendaitem);
    });
};

graficoValdir.selecionaLegenda = function (item) {

    for (var i = 0; i < graficoValdir.Data.length; i++) {
        $("#legend_" + graficoValdir.Data[i].motivo).css("font-weight", "");
    }

    $("#legend_" + graficoValdir.browsersChart.data[item].motivo).css("font-weight", "Bold");
}

graficoValdir.SelecionaCorLabel = function (minhacor) {
    $("#" + graficoValdir.Nomeelemento + " svg text").attr("style", "fill: " + minhacor + " !important");
}

graficoValdir.Atualizar = function () {
    if (graficoValdir.select >= 5) {
        graficoValdir.select = 0;
    }
    else {
        graficoValdir.select++;
    }


    graficoValdir.LimparTela();
    graficoValdir.CarregaGrafico();
}

graficoValdir.LimparTela = function () {
    $("#" + graficoValdir.Nomeelemento).html("");
    $("#" + graficoValdir.DivLegenda).html("");
}

graficoValdir.CarregaGrafico = function () {
    graficoValdir.browsersChart = Morris.Donut({
        element: graficoValdir.Nomeelemento,
        data: graficoValdir.Data,
        formatter: function (value, data) {
            return value;
        }

    });

    for (var i = 0; i < graficoValdir.browsersChart.segments.length; i++) {

        graficoValdir.browsersChart.segments[i].handlers['hover'].push(function (i) {
            graficoValdir.SelecionaCorLabel(graficoValdir.browsersChart.data[i].color);
            graficoValdir.selecionaLegenda(graficoValdir.browsersChart.data[i].motivo);
        });
    }

    graficoValdir.GerarLegendas();

    graficoValdir.browsersChart.select(graficoValdir.select);
    graficoValdir.SelecionaCorLabel(graficoValdir.browsersChart.data[graficoValdir.select].color);
    graficoValdir.selecionaLegenda(graficoValdir.select);
};



